---
layout: post
title: 只是来发个笑话：LaTeX里的路径中的空格
categories:
- Life
tags:
- Joke
- LaTeX
- 空格
- 路径
---

归隐中看到一个很好笑的笑话，于是发过来，原文在[某个Google Groups](https://groups.google.com/forum/#!topic/latexusersgroup/94qri9rtzfc)里，但天朝人民应该看不到，我Google的时候看见的。如下：

> Never use spaces (or other odd characters) in directory or file names. They make your teeth and hair fall out, start nuclear wars, and stop the trains running on time. Stick to A-Z, a-z, 0-9, ".", "-", and "_" for best results.

要是你不笑，咱们见了面估计也就只能谈谈天气了。

这类问题，就像我[前些日子说到的PATH问题](http://cos.name/2011/05/write-r-packages-like-a-ninja/)一样，提出来只想让人像李大嘴一样，垫着枕头撞柱子，一边撞一边念叨：空格！空格！空格！空格！……蕙兰！……


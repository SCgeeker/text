---
layout: post
title: 不为工具所累
categories:
- Life
- Technology
tags:
- LaTeX
- LyX
- PageRank
- 宏
- 陶哲轩
---

周老师分享文章一篇，《[谈谈时间管理--陶哲轩](http://9.douban.com/site/entry/174477609/)》。跑题党眼中的两处问题：一、新浪的PageRank不可能是6，我后来特地看了一下，是8，陶的博客PR要是能赶上新浪，那新浪就得关门了，吹捧不带这么吹的；二、陶曰：正在研究宏，以便能够快速输入`\begin{theorem}…\end{theorem}`之类的LaTeX代码，我心想，嗨，费那事儿干嘛，LyX不是现成的吗。时间紧，话题不展开，不过陶的确是个牛人。

又及：最近心中有些不安分。这种不安分加密之后就是：余弦！余弦！余弦！

又又及：谁来给我讲讲木遥是谁？[傅立叶变换写得很好](http://imaginary.farmostwood.net/542.html)，再具体一点就更好了，得拉到统计之都来。

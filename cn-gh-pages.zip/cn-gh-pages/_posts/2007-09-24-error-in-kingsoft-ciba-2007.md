---
layout: post
title: 金山词霸2007中的一句错误翻译
categories:
- Life
tags:
- 翻译
---

刚才看 excel 的解释，无意间看到关于 outstrip 和 outdo 的一个比较：

> Outstrip is often interchangeable with outdo but strongly suggests leaving another behind, as _in a contest_:

> Outstrip经常和outdo互换，但**在上下文中**它更偏重于把另一个甩在后面这个意思：

> It is a case of the student outstripping the teacher.

> 这是一个学生超过老师的例子。

显然译者当时看走眼了，把 "in a contest" （在一场竞赛中）看作了 "in a context"，挺奇怪的，我感觉一般用 "in _the_ context" 要多得多吧，"in _a_ context" 感觉就不太对劲。


---
layout: post
title: 开始邀请R Core成员投稿
categories:
- Life
tags:
- Felix Andrews
- John Maindonald
- Kurt Hornik
- Moon Yul HUH
- playwith
- R
- R Core
- 会议
---

刚才给[Kurt Hornik](http://statmath.wu-wien.ac.at/~hornik/)写信邀请他给我们的R会议投稿，写着写着，心想何不邀请所有的R Core成员都各自写一篇短文呢？嗯，明天琢磨琢磨，开始邀请所有人。现在的好消息是John Maindonald已经答应投一篇关于数据挖掘的论文。

号外一则：本人于本周三（后天）上午10:00将举行关于统计动画的报告一场（[幻灯片](http://yihui.name/cv/images/See_animation_Yihui.pps)），左邻右舍们感兴趣的欢迎来捧场，另有[Moon-Yul Huh教授](http://stat.skku.ac.kr/myhuh/)应邀讲他的DAVIS系统。两场报告均为英文。另有[`playwith`](http://playwith.googlecode.com/)包的作者[Felix Andrews](http://nfrac.org/felix/)应邀前来（他今年在北京溜达，被John Maindonald给我透露了行踪于是被我逮来人大），有对GTK+/RGtk2以及R统计图形系统感兴趣的可以借此机会找他搭讪。

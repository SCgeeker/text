---
layout: post
title: 我恨Microsoft Office Word！
categories:
- Technology
tags:
- bitmap
- LaTeX
- Office Word
- Windows图元文件
- WMF
- 位图
- 插图
---

谁要是说Word不是垃圾我跟他急。今晚写一篇论文，插图简直让人郁闷死：一个三维图形，用WMF（Windows图元文件）吧，能保持图形的清晰程度，因为它类似于矢量图，但它在Word里面显示巨慢，因为只要你有任何键盘或者鼠标动作，WMF就会更新（redraw），而复杂的图形要redraw一次又非常耗时；不用矢量格式吧，位图贴到Word里面会被自动调整大小，这种自动调整往往让位图变得不清晰，NND，不是垃圾是什么。用不着列举GNU上反对Word的原因，我只有一条反对意见，Word做的东西太丑了。八辈子都赶不上LaTeX。

突然想起来我以前似乎还恨过IE……噫1，貌似我对麦克尔索芙特完全没好感。

---

1 你你你……这是公然抄袭[江堂](http://panshanghu.spaces.live.com/)兄常用的叹词……


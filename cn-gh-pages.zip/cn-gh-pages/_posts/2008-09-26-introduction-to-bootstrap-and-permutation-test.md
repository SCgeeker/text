---
layout: post
title: Bootstrap方法和置换检验（Permutation Test）的入门读物
categories:
- Statistics
tags:
- Bootstrap
- Permutation Test
- 入门读物
- 置换检验
---

今天偶然发现一个文档，非常适合Bootstrap和Permutation Test的初学者读，点击[这里](http://bcs.whfreeman.com/ips5e/content/cat_080/pdf/moore14.pdf)下载。主要是里面内容非常生动活泼，公式的面积一般不超过10平方厘米。而我一般是很不爱看包含有面积大于20平方厘米或者希腊字母超过5个的公式的论文或书籍的。顺带提一下，这是Introduction to the Practice of Statistics第五版中第14章。

[Introduction to the Practice of Statistics第五版中第14章：Bootstrap Methods and Permutation Tests](http://bcs.whfreeman.com/ips5e/content/cat_080/pdf/moore14.pdf)

<del>这次请路人帮忙的事情是，这一章中提到了用Bootstrap方法不断计算光滑曲线，用来说明彩票的趋势并非纯粹偶然。我觉得这个例子举得不错，因此想把它的动画形式写入我的animation包，可以命名为boot.loess()，就用R里面的loess()函数去拟合局部多项式回归好了，每次Bootstrap就用圈圈把抽中的点标示出来，以及添加相应的平滑曲线。这个动画应该很容易做，有志愿者速速报名。报名之前请仔细阅读[animation包的文档](http://animation.yihui.name/animation:start)以及我对[独立同分布数据进行Bootstrap的展示函数boot.iid()](http://animation.yihui.name/dmml:bootstrap_i.i.d)。</del>已经大致在[animation包的2.0-4版本](http://cran.r-project.org/package=animation)中实现，参见`boot.lowess()`函数。

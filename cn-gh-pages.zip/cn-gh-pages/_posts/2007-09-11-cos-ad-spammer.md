---
layout: post
title: COS论坛上有个（些）发广告的白痴
categories:
- Life
tags:
- 垃圾帖子
- 统计之都
---

这个（些）白痴隔几天就来注册一个用户名，然后发一个写EViews图书的广告，白痴大人发广告帖被我看见之后，我马上就会用关键词搜索一下，然后批量删除，为了对付这样的白痴，我特意改了论坛的程序代码，不让同一邮件地址的人注册多次，但这位（些）白痴真是够顽强，每次换一邮箱。好，我看你（们）有多少Email地址可以用，老夫从今天开始在这里直接公布你（们）的邮箱，让别的白痴给你（们）发垃圾邮件：

[pepe23@126.com](mailto:pepe23@126.com) [flashwo1@126.com](mailto:flashwo1@126.com) [flashwo2@126.com](mailto:flashwo2@126.com) (IP: 221.221.154.68) [flashwo3@126.com](mailto:flashwo3@126.com) (IP: 221.221.155.218) [flashwo4@126.com](mailto:flashwo4@126.com) (IP: 221.221.154.68) [flashwo6@126.com](mailto:flashwo6@126.com) (IP: 221.221.154.68) [flashwo7@126.com](mailto:flashwo7@126.com) (IP: 221.221.146.186) [prety168@yahoo.cn](mailto:prety168@yahoo.cn) (IP: 221.221.153.116)

这个（些）白痴每次都招人将个人信息发到他（们）的邮箱：[bookrj@sina.com](mailto:bookrj@sina.com) 或者 [bookcj@sina.com](mailto:bookcj@sina.com)


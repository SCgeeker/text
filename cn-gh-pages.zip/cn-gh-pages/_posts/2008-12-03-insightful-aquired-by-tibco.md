---
layout: post
title: Insightful公司被TIBCO收购了
categories:
- Life
tags:
- Insightful
- S-Plus
- Tibco
- 收购
---

刚刚得知，S-Plus那个公司被收购了，莫非也是金融危机的影响？……

不知此后S-Plus的路会怎样（仅得知软件价钱会涨），拭目以待。

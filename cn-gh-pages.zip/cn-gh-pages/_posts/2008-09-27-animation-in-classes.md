---
layout: post
title: 有谁在课上用统计动画
categories:
- R language
tags:
- animation
- 动画
- 教学
---

从Google Analytics的数据来看，目前至少有这些人在用动画（animation包）：



	
  * University of Southern Denmark数学与计算机系的Marco Chiarandini的讲[组合优化课](http://www.imada.sdu.dk/~marco/Teaching/Fall2008/DM811/index.html)【[链接](http://www.imada.sdu.dk/~marco/Teaching/Fall2008/DM811/visual.html)】

	
  * 中科大统计与金融系Weiping Zhang的概率论与数理统计课【[链接](http://staff.ustc.edu.cn/~zwp/teach.htm)】

	
  * 以色列海法大学统计系的Yoni Nazarathy的Interactive Demonstrations of Stochastic and Statistical Models课【[链接](http://stat.haifa.ac.il/~yonin/interactive_demos_course_winter_09/material.html)】


现在动画的数量以及解释是个大问题，一个人做这些事显得有点吃力，有个合作者就好了。

---
layout: post
title: Jackson's Rules of Optimization
categories:
- R language
tags:
- Brian Ripley
- R-help
- 代码优化
---

今天Ripley在回答一个问题时提到"Jackson's Rules of Optimization"，这两条规则是：


> 1) Don't do it.
2) (For experts only) Don't do it yet.

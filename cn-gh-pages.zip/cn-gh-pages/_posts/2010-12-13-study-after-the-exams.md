---
layout: post
title: 考完试，终于可以安心学习了
categories:
- Life
tags:
- 考试
---

考试严重扰民呐。不考试我还会学点儿东西，要是考试，总是百般不愿意看书。

从小考到大，烤得里焦外嫩。

---
layout: post
title: 恨死Hotmail！恨死垃圾邮件！
categories:
- Life
tags:
- Hotmail
- 垃圾邮件
- 网络
---

Hotmail要么是个白痴（别人可以轻易偷走邮箱里面的联系人信息），要么是故意发广告邮件。Hotmail的用户还是早点逃离吧。

现在垃圾邮件大致分两种，一种是“专业人员”发的，对此我们毫无办法，网络这东西，谁也逮不着谁（就算逮着了，现在有明确的法律制裁么）；另外一种垃圾邮件本来是可以避免的，那就是自己的联系人中某些人在某些网站注册用户，然后稀里糊涂把自己的联系人信息有意无意透露给了那些网站，最后导致的结果就是那些流氓网站无休止地给这些无辜的受害者发邮件说“您好，您的好友XXX在什么什么地方注册了，并邀请您参加，您要不要去啊？”我收到的一般都是英文的，大概形式就是这样：

> Hello, `***@hotmail.com` has added you as a friend on Crickee. `***` needs to confirm that you are friends. Please click this link to accept this friend request: `http://www.***.com/?ik=&^%&$^%#(*@!` It takes just a second. Thank you. `http://www.***.com`, it's free, fun and easy ;-)

痴线！傻子才会去点链接，点了链接无非告诉这些垃圾制造者：喂，我的邮箱是有效的，以后多给我发一些垃圾邮件吧！


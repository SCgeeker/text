---
layout: post
title: 重命名MySQL数据库
categories:
- Technology
tags:
- MySQL
- RENAME
- 网站
- 重命名
---

很简单，RENAME一下就好了。语法：

```sql
RENAME DATABASE db_name TO new_db_name;
# or
RENAME SCHEMA db_name TO new_db_name;
```

这次一边做网页，也算是一边学习MySQL了。其实到现在为止基本上还是一个糊涂蛋。


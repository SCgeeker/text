---
layout: post
title: NB是什么意思？
categories:
- Life
tags:
- NB
---

长久以来，我一直在想，NB到底是神嘛东西的缩写呢？今天终于忍不住了，[Wikipedia了一把](http://en.wikipedia.org/wiki/NB)，原来是[nota bene](http://en.wikipedia.org/wiki/Nota_bene)。还是得勤快一点，不然总是在想。以前脑子里还有好几个缩写，后来我都忍不住一一查出来了，比如aka、foo、bar之类的，总是四处看见它们，却总不明白是嘛意思。

看到本文标题把NB想成“牛逼”的自己蹲到墙角背单词去。


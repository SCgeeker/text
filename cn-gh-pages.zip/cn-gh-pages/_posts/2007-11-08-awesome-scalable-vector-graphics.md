---
layout: post
title: SVG（Scalable Vector Graphics）太牛了！
categories:
- Technology
tags:
- Adobe SVG Viewer
- animation
- grid
- SVG
- 动画
- 可升级矢量图形
---

刚才在[Paul Murrell](http://www.stat.auckland.ac.nz/~paul/)的主页上无意间看到他在写一个包[gridSVG](http://www.stat.auckland.ac.nz/~paul/R/gridSVG_0.5-1.tar.gz)，心想这位大哥最近忙些啥呢，于是下载下来安装了试了试（主要是看见里面有animation）；以前也不知道SVG这种格式，我看Paul的动画是用SVG格式写的，于是又去Google了一下SVG浏览器，发现[Adobe提供这样的浏览器](http://www.adobe.com/svg/viewer/install/)。事实上Firefox已经支持SVG格式了（而且是Native Support！），暂时的缺憾是Firefox的animation模块还在开发中，没有正式发行。

装好Adobe SVG Viewer之后观看了SVG动画片，果然是太牛了！！相比之下我的animation包太老土了，苍天啊，为什么计算机技术进步这么快。

看样子下一步我得考虑SVG格式的动画片了（趁现在它还没有火爆起来），grid graphics也是一大重点。


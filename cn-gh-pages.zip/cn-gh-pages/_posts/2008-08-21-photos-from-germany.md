---
layout: post
title: 八月德国之行：照片
categories:
- Life
tags:
- 德国
- 照片
---

没工夫整理了，乱糟糟扔在这里：

<embed type="application/x-shockwave-flash" src="https://picasaweb.google.com/s/c/bin/slideshow.swf" width="600" height="400" flashvars="host=picasaweb.google.com&captions=1&hl=en_US&feat=flashalbum&RGB=0x000000&feed=https%3A%2F%2Fpicasaweb.google.com%2Fdata%2Ffeed%2Fapi%2Fuser%2F109653178371807724268%2Falbumid%2F5236973148639723793%3Falt%3Drss%26kind%3Dphoto%26hl%3Den_US" pluginspage="http://www.macromedia.com/go/getflashplayer">

话说我今天睡了16个小时，不知道有没有破世界纪录。

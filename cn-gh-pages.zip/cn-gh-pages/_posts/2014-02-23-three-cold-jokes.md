---
layout: post
title: 冷笑话三则
categories: [Life]
tags: [Joke]
---

一个妹子打电话给我说她家没人，让我过去。我去了。她家真的一个人都没有哎。（这个很有日式笑话风范）

> "A girl phoned me the other day and said "Come on over, there's nobody home." I went over. Nobody was home." -- Rodney Dangerfield

下面这个没法翻译。fork是个多义词。

> "When you come to a fork in the road, take it." -- Yogi Berra

我老家方言把“鞋子”叫“孩子”，高中时我一个同学给我讲了一个冷笑话，可以当作是上面的并行版：

> 一位大妈坐在江边对着江水痛哭“我的孩子啊！……”一位热心小哥看见赶紧冲过来问完“你孩子在哪儿？”就跳进江里了，过了十分钟，小哥很沮丧地爬上岸跟大妈说“非常抱歉，你的孩子我没捞起来，找了半天只捞到他的一只鞋子”。

这位同学表达了对管理国家的担忧：一个有246种奶酪的国家怎么管理得过来？！（这是英美讽刺范儿）

> "How can you govern a country which has 246 varieties of cheese?" -- Charles De Gaulle

三个冷笑话说完了，再外加一个热的，献给广大博士僧（我自己答辩时斗胆引用了这个）：

> The average Ph.D. thesis is nothing but a transference of bones from one graveyard to another. -- J. Frank Dobie, "A Texan in England", 1945

---
layout: post
title: 终于更新完程序包了：animation 1.0-0
categories:
- R language
tags:
- animation
- R包
- 动画
---

累死我了，花了五六天时间才把动画包的框架全部改过来，一天到晚啥都不干，就是埋头改代码。剩下的工作还是“路漫漫其修远兮”——[AniWiki](http://animation.yihui.name/)的内容需要慢慢填充，现在只是把动画全都放上去了，关于统计方法的原理介绍都还没有。

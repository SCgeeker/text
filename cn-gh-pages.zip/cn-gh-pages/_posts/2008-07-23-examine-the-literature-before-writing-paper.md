---
layout: post
title: 写论文之前要多多考察环境
categories:
- Life
tags:
- GRE
- 引用
- 烧香
- 论文
---

今天无意间发现了三个月前[Jan de Leeuw](http://gifi.stat.ucla.edu/)把我的一篇论文分到了一位法国大哥[Romain Francois](http://francoisromain.free.fr/)手里。心想完蛋了，因为没在论文中提到这位哥哥的[R Movie Gallery](http://addictedtor.free.fr/movies/)，但愿这位主子宽宏大量，不要把我毙了（过了三个月了居然还没给答复）。其实[Paul Murrell](http://www.stat.auckland.ac.nz/~paul/)早跟我提起过，只是写文章时忘了引一下了。

另外突然想起来还得给GRE作文烧香，本小子愣是一篇作文都没练过就上场了（处女作就献给ETS了），“裸奔”到这种程度，估计史上也没几个人了吧。

    (   )   (    )   (    )
    (  )  (   )    (   )
    ( ) (  )  (  )
    () () ( )
    || || ||
    || || ||
    || || ||
    || || ||
    || || ||
    || || ||

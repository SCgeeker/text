---
layout: post
title: 奥巴马标准领导照
categories:
- Life
tags:
- 奥巴马
- 照片
---

我晕：


![奥巴马标准领导照](http://pic.yupoo.com/hecaitou/0639072f1a13/21iis5le.jpg)

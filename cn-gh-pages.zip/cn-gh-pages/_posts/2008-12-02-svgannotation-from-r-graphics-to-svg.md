---
layout: post
title: SVGAnnotation：从R图形到SVG的（全面）支持
categories:
- R language
tags:
- Duncan Temple Lang
- Firefox
- Omegahat
- Opera
- R包
- SVG
- SVGAnnotation
- 动画
---

Duncan Temple Lang总是喜欢做一些有趣的东西，这回，他想了个主意，先用Cairo生成SVG图形，然后编辑XML文件，把SVG的那些特性事后加进去，例如图形中的文本标记、超级链接、动画等等。

SVGAnnotation包参见：[http://www.omegahat.org/SVGAnnotation/ ](http://www.omegahat.org/SVGAnnotation/ )

感兴趣的朋友注意使用Firefox浏览示例页面，对于SVG动画，Firefox还不太能支持，尚在努力开发中，所以如果想看动画，还是Opera吧。

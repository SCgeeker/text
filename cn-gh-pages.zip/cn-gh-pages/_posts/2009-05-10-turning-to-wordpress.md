---
layout: post
title: 我也想转WP啊……
categories:
- Technology
tags:
- Wordpress
- 搬家
---

话说我也早就想用WP了，只是嫌换系统麻烦。今日遇见一位[女博主](http://www.loyhome.cn)，着实吓了我一跳。网上溜达这些年，还真没见过哪位lady会自个儿捣鼓PHP+MySQL之类的东西。溜了一圈，发现这位大人也是从别的博客系统转入Wordpress的，继而发现已经有从Bo-blog转到WP的教程了。于是乎，还看什么看？搬！

![](http://i.imgur.com/TrIGky8.jpg)

---
layout: post
title: 千万不要一口气写500行以上的程序
categories:
- Technology
tags:
- Celine Dion
- R
- 编程
---

直到现在我的心脏还在怦怦跳，原因只是因为昨天和今天一直在修改调试一个半年多以前编的一个抽样程序，刚才正式运行了一遍，总算基本上搞定了，不过在等待程序运行的几分钟里，心里还是极度紧张的——生怕什么地方又出错。

500多行的程序其实不算大，但是时间一长，各个变量的意思就需要花时间回忆（尽管有注释但仍需要理清思路），大脑跟着for/while的循环一起转圈，“绞尽脑汁”的“绞”大约就是这个绞法吧……写程序一定要模块化，分结构写，这样以后修改起来心理压力会小很多。这两天说是修改程序，其实相当大一部分程序都用在心理准备上了——看一大堆已经快忘记的代码确实是一件很折磨人的事情（简直就是酷刑）。

为了防止外界打扰，我一边修改一边戴着耳机听音乐，发现Celine Dion的这几首歌还不错：Immortality、My Precious One、A New Day Has Come，当然，那些经典的也都不错，比如Falling into You、There You'll Be等。我最喜欢的是这首[Immortality](http://www.youtube.com/watch?v=SGeROT6fNrs)。


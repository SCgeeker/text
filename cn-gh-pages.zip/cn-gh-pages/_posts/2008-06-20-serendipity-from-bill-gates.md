---
layout: post
title: 觉得天上会掉钱的举手！（比尔盖茨会给大家发钱？）
categories:
- Life
tags:
- 垃圾邮件
- 比尔盖茨发钱了
- 白日梦
---

刚才从一个朋友那儿收到一封很有意思的邮件，标题是巨长一串“FW: Fw : Fw : Fw : Fw : Fw : Fw : ?转发:……”，打开来一看，原来是告诉我天上掉钱了，让赶紧打开口袋接着：

> Don’t Know True Or False, Just Have a Try
請不要管它是真還是假，試一下！　如下文章的意思是：（水平有限，可能翻譯得不是很正確，班門弄斧了！）
Dear Friends,
Please do not take this for a junk letter. Bill Gates is sharing his fortune. If you ignore this you will repent later. Microsoft and AOL are now the largest Internet companies and in an effort to make sure that Internet Explorer remains the most widely used program, Microsoft and AOL are running an e-mail beta test.
親愛的朋友們，
請不要把此郵件當作是垃圾郵件。比爾.蓋茨正在施捨他的財富。如果你無視此封郵件稍後你將會追悔莫及.Microsoft and AOL 是現今最大的因特網公司並致力於確保因特網Windows資源管理器依然是使用最廣的程序，Microsoft and AOL 正在進行E-mail第二個階段的測試。

> When you forward this e-mail to friends, Microsoft can and will track it (if you are a Microsoft Windows user) for a two week time period.
噹你把此e-mail轉送給你的朋友時，微軟將跟在兩周內蹤它（如果你是Microsoft Windows 的使用者）。
For every person that you forward this e-mail to, Microsoft will pay you $245.00, for every person that you sent it to that forwards it on, Microsoft will pay you $243.00 and for every third person that receives it, you will be paid $241.00. Within two week! s, Microsoft will contact you for your address and then send you a cheque.
對於每一個轉發此mail給朋友的人，微軟將會付給你$245。對於每一個你轉發了的人，別人又繼續轉發的人，微軟將付給你$243並且每三個人收到此mail，你將會得及$241的付款。在兩周內，微軟將會聯繫你的地址並給你一張支票！

我心想世上有这么好的事么，本着“外事不决问Google，内事不决问娇妻”的首要原则，随手Google了一下，感觉只有三个字：toooooo old! （画外音：你会不会数数啊？）

话说[这里有一个页面](http://urbanlegends.about.com/library/blmsaol.htm)澄清这个恶作剧，原来这是上个世纪的垃圾邮件，经过新世纪的洗礼居然还在网上传播，不得不佩服人们对不劳而获的执着向往。我觉得如果人们对自己的理想也有这么执着的信念，那发财只是迟早的事情。俗话说，空即是色，色即是空。按老衲的理解，意思就是，有钱就是没钱，没钱就是有钱，要是一辈子奔着钱去就得不到大钱，赚到大钱的反而是那些没有打算一辈子奔着钱去的人。

有趣的是我可以从转发邮件中一直追溯到第一个发这封邮件的人，中间转手的人来自各行各业，某大学的，某LG的，某株式会社的，某西门子的，某中兴通讯的，等等。实在有趣。下次我干脆给这些人发一封邮件说，比尔盖茨说了，他们正在用IE测试追踪谢益辉的博客，凡是每天访问1次的同志能获得$2，访问两次获得$4，三次$8，以此类推，上限$1024。我看看我的小窝访问量会不会在下个月暴增。

另外，说到垃圾邮件的问题，洒家对它仇视已久，仁慈的主以及涛哥以及未来的奥巴马大叔啊，您们就早点立法惩治一下垃圾邮件吧。话说最近Gmail的垃圾邮件是越来越多，tnnd，寡人对卖软件的、推销网站的、卖药的都很是不喜欢很是不喜欢很是不喜欢。

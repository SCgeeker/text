---
layout: post
title: 网页中的图片点击放大效果：Highslide和Lightbox
categories:
- Technology
tags:
- CSS
- Firefox
- hislide
- HTML
- Internet Explorer
- JavaScript
- lightbox
- 图片缩放
- 网页
---

这两个网站是我所看到比较经典的JS图片放大效果网站：

- <http://vikjavev.no/highslide/>
- <http://www.huddletogether.com/projects/lightbox/>

前者是在页面内缩放，后者是采用的“全屏”效果，我看后者的代码稍微简单一些，就采用了后者，不过也借鉴了前者的一个放大镜图标，这样有助于提醒访问者他所看到的这幅图片时可以继续放大的；不过这个图标还费了我半天劲才让它在IE中也显示出来，主要是IE对CSS中文件路径的解析比较奇怪，而Firefox就能正确解析出来。

那么以后本站中的图片就可以有缩放效果啦！而且对于多幅图片，还可以以幻灯方式依次浏览，嗯，8错8错。


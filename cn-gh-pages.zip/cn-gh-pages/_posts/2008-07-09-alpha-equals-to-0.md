---
layout: post
title: 置信水平最高的统计推断
categories:
- Featured
- Statistics
tags:
- Joke
- 天气预报石头
- 统计推断
---

收拾电脑桌面，看见了这张图片，没地方放，发上来供大家乐乐，看看人家的统计推断艺术到了什么境界：

![](http://i.imgur.com/XbsWY.jpg)

想起上回在[首经贸演讲]/en/2007/10/jokes-in-statistics/)中提到的一则笑话：

> A statistician is someone who is skilled at drawing a precise line from an unwarranted assumption to a foregone conclusion.

这块天气预报石和这则Joke颇有异曲同工之处。

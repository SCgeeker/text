---
layout: post
title: 口疮怎么办
categories:
- Life
tags:
- 口疮
---

Google了一下，结果是：要保持乐观，要坚持写日记，等等。再看一下如何预防口疮，结果有：小心刷牙。

你不早说……

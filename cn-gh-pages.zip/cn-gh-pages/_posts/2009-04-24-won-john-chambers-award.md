---
layout: post
title: 本小子还真中了John Chambers软件奖
categories: [R language]
tags: [animation, John Chambers, R, 动画, 统计软件]
---

此时此刻，俺哆嗦着告诉各位客官，俺真的中奖了。

话说两个月前，我[介绍了一下John Chambers软件奖](http://yihui.name/cn/2009/02/introduction-to-john-chambers-software-award/)，当时并没有指望获奖，只是打探打探情况，搞明白之后等我明年好好琢磨一个靠谱的软件之后再正式参加。结果，不知是美国人民都忙着对付金融危机了，还是一共就我一个人参加，或是怎么的，今日打开邮箱，发现我被通知得奖（中奖？）了。我愣了半天，觉得这是在做梦。

好吧，两个月前说了要请客，那么那篇日志底下的观众朋友们请赶紧拿出小本本记下，“谢某人欠俺一顿大餐”。

做动画都能获奖……敢问谱在何方啊……管它呢，反正是美国人的钱，俺遵旨，8月去华盛顿领钱，顺便领奖。

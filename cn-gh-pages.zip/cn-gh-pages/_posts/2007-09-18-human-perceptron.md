---
layout: post
title: 风吹草动惊蛇
categories:
- Life
tags:
- Perceptron
- 感知器
- 机器学习
- 积累误差
---

这个也有点意思（场面有点像炒股）：

![风吹草动惊蛇](http://i.imgur.com/M0E5N.gif)

其实这简直就是一个最经典的机器学习中的感知器（Perceptron），从传入Input经过中间的“训练”到输出Output——只不过这是一个糟糕的感知器。将它视作数值计算中的误差累积也未尝不可。


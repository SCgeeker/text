---
layout: post
title: 计量经济学与R
categories:
- R language
tags:
- JSS
- R
- 计量经济学
---

[JSS第27期](http://www.jstatsoft.org/v27)为计量经济学专辑，对计量经济学感兴趣的不妨看一看。不过一共只有7篇论文（不算第1篇），内容可能不太全面。

看样子Achim Zeileis兴趣还挺广泛。

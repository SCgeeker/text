---
layout: post
title: 关于气煞人的LaTeX浮动
categories:
- Featured
- Technology
tags:
- LaTeX
- LyX
- MSG
- 民以食为上帝
- 浮动
- 红烧肉
---

还是DJ兄给力，给的这篇[关于如何使用LaTeX浮动召唤术的神帖](http://www.howtotex.com/tips-tricks/control-float-placement)相当的有用。书中的那些稍微高一点的图形现在都乖乖浮动到页面上方去了，下面的文字如流水般淌过。这事情，只能用《十全九美》第5分06秒的场景描述了：

![太强啦](http://i.imgur.com/CwBsAqs.png)

对于“按下葫芦浮起瓢”（卢编语，非常贴切）的LaTeX浮动，现在我们可以引用《疯狂的石头》10分17秒的场景来描述：

![老子叫你飞](http://i.imgur.com/4rHon0B.png)

尽管[前面我说参考文献很可恶](/cn/2011/03/hacking-econometrics/)，但长期在此溜达的客官也许可以发现以上两部老片子是我常用的参考文献。

又及：晚上做了真正意义上的红烧肉，红烧肉呀么红烧肉，没得五花肉，果然是烧不成的。

又又及：关于LyX和pgfSweave的工作似乎惊动了LyX中央，今天“上面”来人了，也许LyX 2.0里面我能把pgfSweave给整进去。这是个好事。

再及：MSG包已经扔到CRAN上了，不过Windows版本的包目前还没编出来。这本书的最后一节也已经收到，但关于R介绍的一章要大幅度重写，然后才真正算是初稿完成，万里长征走完了一步。

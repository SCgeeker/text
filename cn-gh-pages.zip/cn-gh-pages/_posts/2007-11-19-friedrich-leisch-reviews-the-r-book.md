---
layout: post
title: Friedrich Leisch评The R Book
categories:
- Life
tags:
- Friedrich Leisch
- Michael J. Crawley
- Rnews
- The R Book
---

2007年Wiley出版的"[The R Book](http://www.bio.ic.ac.uk/research/mjcraw/therbook/index.htm)"为伦敦帝国理工学院的Michael J. Crawley所著，结果在[10月份的Rnews](http://cran.r-project.org/doc/Rnews/Rnews_2007-2.pdf)上面被Friedrich Leisch打成了马蜂窝。有意思。

在他的评论中，好几处都是针对排版问题的；说实话我还真是很少见统计界的人用MS Word写书或写文章，放眼望去大家全都是LaTeX。Michael的书中，严重缺乏结构感，整本书只有27章的序号，其它小节一律光秃秃没有编号，这也太可怕了，一章上百页，看半天看不到尽头，又不是读小说，谁受得了啊。里面R程序代码竟然不用等宽字体，这简直是常识了吧？哪有写代码用比例字体的？……如果用LaTeX，一般人都会乖乖用`verbatim`环境去排版程序代码，出来也就是等宽字体。

这作者也挺能写，1000多页的书，没有功劳也有苦劳了。

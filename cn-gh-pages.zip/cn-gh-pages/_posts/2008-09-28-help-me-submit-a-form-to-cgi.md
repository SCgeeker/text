---
layout: post
title: 请熟悉JavaScript、DOM或Ajax的路人帮忙
categories:
- Technology
tags:
- Ajax
- JavaScript
- 表单
---

在下现在有个小技术问题，自己去钻研太浪费时间了，因此拜求江湖高手帮我一把。问题是这样，我想提交一个表单给某个网站的CGI执行，然后把执行返回结果中的图片地址都拿出来。提交和执行过程中不要影响当前的HTML页面（即：不要直接跳转到CGI页面，这似乎是Ajax的特征）。以下是普通的表单界面：

plot(1); plot(rnorm(100)); plot(rnorm(100))

返回的图片URL放在一个数组中即可。谢谢！

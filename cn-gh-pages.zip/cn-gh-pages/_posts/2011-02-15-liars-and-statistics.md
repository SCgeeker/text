---
layout: post
title: 撒谎无底线
categories:
- Life
tags:
- 统计数据
- 谎言
---

对统计局玩出来的CPI上涨4.9%，问一百个人，一百二十个人不信。[87.53%也就罢了](http://yihui.name/cn/docs/StatGraphics/Graphics-in-Stat-Models.pdf)，为了不压线（5%）玩儿这4.9%有意思吗？

那77块钱房租的事情可以说是开创了天朝撒谎新纪元：连最大的头都可以骗了，还有谁不能骗的？

这一届朝廷之乏力，已经是再明显不过的事实了。

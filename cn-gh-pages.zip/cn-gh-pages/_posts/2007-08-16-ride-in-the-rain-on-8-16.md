---
layout: post
title: 8月16日骑车又下雨
categories:
- Life
tags:
- 下雨
- 自行车
---

[两年前的今天](/cn/2005/08/ride-to-tianjin-in-16-hours/)，我冒着暴雨骑我的破自行车从北京到了天津；今天白天骑车去BIStone公司，结果晚上的时候下雨了。回来路上马上就想起了两年前在暴雨滂沱中几乎以游泳的形式骑车的情景。


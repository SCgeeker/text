---
layout: post
title: 他说他的眼里只有R
categories:
- Life
tags:
- John Maindonald
- R
---

话说John Maindonald给我回信，开头为：Dea**R** Yihui...

嘿，这老爷子，敢情世上到处都是[R](http://www.r-project.org)啊。

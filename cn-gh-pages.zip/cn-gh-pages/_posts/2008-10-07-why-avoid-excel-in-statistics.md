---
layout: post
title: 再谈为什么不用Excel做统计分析
categories:
- R language
tags: [Excel, R, 统计计算]
---

没想到魔鬼经济学（Freakonomics）在NY Times的[Blog](http://freakonomics.blogs.nytimes.com/)上也写起R来了。话说昨天有这么一篇“免费的超牛牛计算软件”（[Free Super-Crunching Software](http://freakonomics.blogs.nytimes.com/2008/10/06/free-super-crunching-software/)），作者小小赞扬了一把Excel可以多么灵活多么实用，然后介绍了一下R。后面顿时狂风大作、飞沙走石、昏天黑地。

其中，第一位留言的同学给了[一篇小文档](http://pages.stern.nyu.edu/~jsimonof/classes/1305/pdf/excelreg.pdf)，对统计分析的人来说值得警醒。

---
layout: post
title: 频率学派和贝叶斯学派（George Cassella的演讲）
categories:
- Statistics
tags:
- George Cassella
- 贝叶斯学派
- 频率学派
---

George Cassella九月做了一场关于频率学派和贝叶斯学派的演讲（[幻灯片](http://www.stat.ufl.edu/~casella/Talks/BayesRefresher.pdf)）。我不知道的是，原来贝叶斯学派的大规模兴起才不过二十年时间。

---
layout: post
title: 说编辑编辑到
categories:
- Life
tags:
- 审稿
- 编辑
- 论文
---

昨天[刚说了写关于论文和编辑的事情](http://yihui.name/cn/2011/02/papers-and-editors/)，今天一开电脑，发现某刊物让我帮忙审论文；小喽罗审大老前辈的文章，有点儿意思。

---
layout: post
title: Dokuwiki数学公式插件基本搞定
categories:
- Technology
tags:
- Dokuwiki
- LaTeX
- 动画
- 数学公式
- 网站
---

今天这一天我写完了动画插件的说明文档，顺便把别人的一个数学公式插件修改了一下，让它用起来更顺手一些，这样在这个Wiki中就可以很方便地生成LaTeX数学公式了。

- 动画插件：<http://animation.yihui.name/wiki:animation_plugin>
- 动画示例：<http://animation.yihui.name/wiki:animation_example>
- 数学公式：<http://animation.yihui.name/wiki:math>

至此，这个站点的主要功能算是齐全了。只剩下动画插件还有一个小地方需要扩充一下。

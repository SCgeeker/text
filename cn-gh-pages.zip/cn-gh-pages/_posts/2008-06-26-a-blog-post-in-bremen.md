---
layout: post
title: A Blog Post in Bremen
categories:
- Life
tags:
- Bremen
- DataVis VI
- Germany
- Jacobs University
---

I have finished my talk in Jacobs University this afternoon and I got fewer comments than I expected; maybe I can discuss with them in the rest days.

By the way, Bremen is really beautiful! You can see green plants everywhere, but on the other hand, I can hardly find any people walking on campus in most of time except the workshop participants -- the population of Bremen is so small?...

Generally speaking, I'm both tired and exciting in these two days, and sometimes even depressed. It is indeed a special experience to be abroad. I'll write in details when I go back to Beijing.


---
layout: post
title: Gmail的垃圾邮件判别器不和谐
categories:
- Technology
tags:
- Gmail
- Joke
- 科学发展观
---

我天朝的科学发展观都敢判为垃圾邮件，Gmail不想在这里混了啊？

![科学发展观（垃圾邮件）](http://i.imgur.com/j18IQif.png)

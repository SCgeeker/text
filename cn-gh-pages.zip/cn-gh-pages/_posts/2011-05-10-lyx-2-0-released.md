---
layout: post
title: LyX 2.0横空出世
categories:
- R language
tags:
- LyX 2.0
- pgfSweave
- Sweave
---

这是旧闻了。只不过我这两天在埋头苦改其中的Sweave部分，刚刚改得差不多了，发了个大大的SVN补丁过去。可惜没能赶在2.0之前搞定。pgfSweave也作为单独的模块加进去了，有超级牛力。不知能否赶上2.0.1的趟，也不知2.0.1啥时侯发布。

总之以后不用费劲折腾了，配置啥的都将变得很简单。

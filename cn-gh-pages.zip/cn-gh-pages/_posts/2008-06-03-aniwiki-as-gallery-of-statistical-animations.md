---
layout: post
title: 统计学动画维基百科
categories:
- R language
tags:
- 动画
- 维基百科
- 网站
---

终于可以有几天时间放手玩玩儿了，于是乎开始一项新的工程：[统计学动画维基百科](http://animation.yihui.name)。

基于Wiki来做网站，相信会省事很多。过去的两天时间里刚刚重写完支持网页动画的JavaScript，下一步就是写一个Wiki插件，将Wiki的语言转化为HTML代码，这一点尚需要学习一点PHP；再下一步就该修改更新R程序包了；等这一切框架搭建好之后便可暂时放手网站，开始准备[DataViz VI](http://www.jacobs-university.de/schools/shss/awilhelm/)的论文。

近日接连收到Oxford和Stanford学生来信，大家对animation的评价用词最多的是“impressed”，当然这样的话万不可直接理解为褒义，等有人说“useful”了才算数。如德鲁克所提醒的：

> ……发现任何由于恃才傲物而造成的偏见和无知，并且加以克服。……

不过无论如何，有人关注并使用动画也算是走出一小步了。

---
layout: post
title: 去年R会议的报告
categories:
- R language
tags:
- R
- R语言会议
- 会议报告
---

话说前天在海关开会的时候没事干，便偷偷在下面写去年R会议的报告，三下五除二写完昨天发给The R Journal了，今天主编大人说，i suspect this will be a nice article，看来悬了，估计是发不出来了。R core咋就不能照顾照顾广大中国R人民呢……

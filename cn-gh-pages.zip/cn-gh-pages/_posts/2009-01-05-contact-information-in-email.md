---
layout: post
title: 邮件的作用
categories:
- Life
tags:
- 吴老师
- 邮件地址
---

中午走在路上，突然接到吴老的电话，我心里纳闷，他怎么知道我的手机的，上楼遇见他，他得意洋洋地告诉我，手机号是从我的邮件中找出来的。老爷子果然聪明。

外一则

刚才有位马来西亚的先生/小姐给我发邮件，焦急地询问另一人的Email地址。结果他/她自己的Email地址是这样的（`*`部分隐去了姓名和我自己的Email）：

	From: *** *** **<hairul>**
	Date: Mon, Jan 5, 2009 at 10:09 AM
	Subject: Assistance needed urgently
	To: ***@****

由于这位同志自己的Email地址都没写对，别人都无法回复他/她的邮件。真是无语。

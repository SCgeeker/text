---
layout: post
title: R的data frame怎么提取一列
categories:
- Life
tags:
- data frame
- Joke
- R语言
- rtist
- 统计之都
---

看了这个帖子<http://cos.name/cn/topic/7393>，把我笑喷了。楼主莫介意，丝毫没有取笑的意思。rtist一定哭笑不得，急坏了。


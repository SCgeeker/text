---
layout: post
title: 死翘翘……缺失值……
categories:
- Statistics
tags:
- Classfication and Regression Tree
- Ensemble Method
- Missing Value
- 分类与回归树
- 缺失值
- 集成方法
---

第一次意识到缺失值是很讨厌的东西，尤其是缺失值很多的时候。

若数据的每一行都有缺失值，那么（若没有任何补救措施的话）：k最近邻（kNN）会失败，神经网络会失败，Logistic回归会失败，支持向量机会失败……

我的论文马上急剧缩减为“集成树”而不能写“集成分类器”了。


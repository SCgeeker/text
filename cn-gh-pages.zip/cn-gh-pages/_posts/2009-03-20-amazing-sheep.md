---
layout: post
title: 卧抵个马呀，这还是羊么？
categories:
- Life
tags:
- Youtube
- 羊
- 视频
---

这羊群太惊人了……



看不见视频的直接看网址：[http://www.youtube.com/watch?v=D2FX9rviEhw](http://www.youtube.com/watch?v=D2FX9rviEhw)

---
layout: post
title: R 2.8.0终于又能完美支持中文路径了
categories:
- R language
- Statistics
tags:
- R
- 中文支持
---

不知是从R 2.6.0还是哪一个版本开始，RGui对中文的支持变得很差，以前我经常用拖拽的方式获得文件的路径，后来发现拖拽到Console里面之后中文路径会变成乱码，这一点很是不爽。今天2.8.0的Windows版本也已经发布，安装后看了一下，发现这个问题又恢复到能用了。

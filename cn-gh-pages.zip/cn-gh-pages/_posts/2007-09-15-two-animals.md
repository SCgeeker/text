---
layout: post
title: 无题
categories:
- Life
tags:
- GTalk
- 庐山瀑布汗
- 聊天
---

这个有点意思：

![Hello，大马户！嗯？](http://i.imgur.com/NnaXhzX.jpg)


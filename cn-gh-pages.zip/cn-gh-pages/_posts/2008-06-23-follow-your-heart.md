---
layout: post
title: Follow Your Heart
categories:
- Life
tags:
- 兴趣
- 生活
---

刚才看了两个小片子，一个是在世界各地跳舞的人，一个是爱情故事。

跳舞的这位Matt惊动了世界，所做的事情极其简单，就是在各地跺跺脚抖抖手，然后录下来。他爱玩，也玩出了名堂。

<iframe width="560" height="315" src="http://www.youtube.com/embed/zlfKdbWwruY?rel=0" frameborder="0" allowfullscreen></iframe>

爱情故事这个片子叫"THE DANISH POET"，讲的是人生各种机缘巧合；有人顺从了自己，有人顺从了别人。

<iframe width="560" height="315" src="https://www.youtube.com/embed/2lXcufpx2Nk" frameborder="0" allowfullscreen></iframe>

两部片子看起来也没什么联系，不过都透露出一点信息：要知道你心里真正想要的是什么或者真正感兴趣的是什么，唯有如此，人生才不会留下太多遗憾。

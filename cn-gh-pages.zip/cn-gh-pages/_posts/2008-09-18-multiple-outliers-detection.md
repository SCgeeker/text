---
layout: post
title: 多个离群点的探测
categories:
- Featured
- R language
tags:
- 抽样
- 离群点
---

据说多个离群点的探测问题是一个统计难题，这里是我的[粗略想法](https://github.com/yihui/yihui.github.com/releases/download/latest/multiple-outliers.swf)，由于太粗略，我就不解释了。

<embed width="600" height="400" src="https://github.com/yihui/yihui.github.com/releases/download/latest/multiple-outliers.swf" type="application/x-shockwave-flash">

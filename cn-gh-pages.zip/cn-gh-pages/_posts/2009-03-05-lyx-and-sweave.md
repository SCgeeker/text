---
layout: post
title: LyX和Sweave
categories:
- R language
tags:
- LyX
- R
- Sweave
- 动态报告
---

> 2013/02/05更新：knitr包已经可完美替代Sweave，并且在LyX中有很好的支持。参见[这篇日志](/cn/2010/02/misc-issues-in-latex-lyx-r-sweave-pgfsweave/)。

有些LaTeX用户可能觉得敲代码太费事了，那么这里推荐一下LyX。[LyX](http://www.lyx.org)是一个所见即所得的编辑器，因为它基于LaTeX，所以排版质量没啥好说的。关键是它可以和Sweave结合起来用，只要到CRAN[下载LyX相关配置文件](http://cran.r-project.org/contrib/extra/lyx/)就可以了。

详细使用方法参见[R News 2008年第1卷](http://cran.r-project.org/doc/Rnews/Rnews_2008-1.pdf)的第一篇文章"Using Sweave with LyX"。

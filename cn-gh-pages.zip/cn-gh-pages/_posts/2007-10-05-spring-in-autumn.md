---
layout: post
title: 春天来了！
categories:
- Life
tags:
- 校园
- 花花草草
---

在校园里游走，一幅暮春三月草长莺飞<sup>(1)</sup>的景象让我忍不住拿出手机把这些花花草草虫虫鸟鸟拍了下来。

![spring in fall 1](http://i.imgur.com/d1DXZ.jpg)

![spring in fall 2](http://i.imgur.com/AePr1.jpg)

![spring in fall 3](http://i.imgur.com/T2hkU.jpg)

![spring in fall 5](http://i.imgur.com/GQxnY.jpg)

![spring in fall 6](http://i.imgur.com/qqnTu.jpg)

![spring in fall 4](http://i.imgur.com/fx3Wa.jpg)

注意别把上图中那只蜂看倒了：虽然它的屁股长得像头，而头长得像屁股。当时为了拍这只蜂，真是费了牛鼻子劲，它采蜜的速度太快了，在每一朵五角星上大约都只停留半秒到一秒时间，导致我几乎给它拍了一套写真集。

---

注：(1) 麻烦小麻雀们友情客串一下“莺”了。


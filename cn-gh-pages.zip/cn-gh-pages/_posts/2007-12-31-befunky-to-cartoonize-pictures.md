---
layout: post
title: 一个卡通化图片/照片的网站
categories:
- Technology
tags:
- 卡通
- 网站
---

在这里：<http://www.befunky.com>

我利用它转了一张照片，然后结合Fireworks（作图软件）以及R完成了我的新年卡片。和我有过邮件联系的同志们这两天应该都可以看见那张图了（由于联系人忒多，壹千多头，刚发八百头Gmail就不让我发了，可能得等明天后面才能把所有的人都发完）。


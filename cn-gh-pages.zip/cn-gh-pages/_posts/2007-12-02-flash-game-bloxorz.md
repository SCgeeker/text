---
layout: post
title: 发一个（无聊的）搬砖头Flash游戏：Bloxorz
categories:
- Life
tags:
- Bloxorz
- Flash
- 游戏
---

昨晚写完论文，收到一封邮件，给我发了个游戏，号称全球只有4个人通关，我当时就很怀疑怎么会有这么高智商的游戏，于是乎本同学（低IQ）就查探了一把：

<embed src="http://www.miniclip.com/games/bloxorz/en/bloxorz_miniclip.swf" allowFullScreen="true" quality="high" width="600" height="375" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" />

前前后后大约搬了四个小时才把33级搬过去，看来我也就只能玩玩这种简单游戏了。

另外需要说明的是，本游戏不适合有心脏病的同志们玩（就是块破砖头，没什么恐怖的，但是你玩一会儿就知道什么地方吓人了，我被吓了至少四五十次。


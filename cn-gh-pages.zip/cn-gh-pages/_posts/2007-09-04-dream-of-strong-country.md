---
layout: post
title: 强国梦
categories:
- Life
tags:
- Olympic
---

这篇文章不错，不过貌似找不到电子书：<http://finance.sina.com.cn/g/20070810/00353868755.shtml>


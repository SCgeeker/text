---
layout: post
title: 阴差阳错
categories:
- Life
tags:
- If
- Rudyard Kipling
- 淡定
- 美帝
---

自从来到美帝，生活总是一波三折，有时还七八折。折得我现在见怪不怪了，对“福兮祸之所藏，祸兮福之所倚”有了深刻认识。这人呐，遇见好事不能太得意，遇见坏事也不能太失落，正所谓“不以物喜，不以己悲”。事情来一件解决一件，水来将挡，兵来土掩。今日读到老诗一首：

> If
> 
> Rudyard Kipling
> 
> If you can keep your head when all about you  
Are losing theirs and blaming it on you;  
If you can trust yourself when all men doubt you,  
But make allowance for their doubting too;  
If you can wait and not be tired by waiting,  
Or, being lied about, don't deal in lies,  
Or, being hated, don't give way to hating,  
And yet don't look too good, nor talk too wise;

> If you can dream - and not make dreams your master;  
If you can think - and not make thoughts your aim;  
If you can meet with triumph and disaster  
And treat those two imposters just the same;  
If you can bear to hear the truth you've spoken  
Twisted by knaves to make a trap for fools,  
Or watch the things you gave your life to broken,  
And stoop and build 'em up with wornout tools;  

> If you can make one heap of all your winnings  
And risk it on one turn of pitch-and-toss,  
And lose, and start again at your beginnings  
And never breath a word about your loss;  
If you can force your heart and nerve and sinew  
To serve your turn long after they are gone,  
And so hold on when there is nothing in you  
Except the Will which says to them: "Hold on";

> If you can talk with crowds and keep your virtue,  
Or walk with kings - nor lose the common touch;  
If neither foes nor loving friends can hurt you;  
If all men count with you, but none too much;  
If you can fill the unforgiving minute  
With sixty seconds' worth of distance run -  
Yours is the Earth and everything that's in it,  
And - which is more - you'll be a Man my son!

这Kipling老爷子写了一大通，我总结无非就两个字：淡……！定！

![淡定](http://i.imgur.com/2R9iyPv.jpg)

---
layout: post
title: 金狗宝金狗宝金狗饿了喂
categories:
- Life
tags:
- animation
- Duncan Temple Lang
- 动画
- 圣诞
---

过节就给点过节的气氛吧，尽管美国人不会过五四青年节。

昨晚注意到Duncan Temple Lang在他的统计计算课上用到了我的kNN动画，心里小小激动了一下，呜哈哈哈。另外也注意到加拿大某老师把动画作为作业布置给她的学生了，让学生参考animation包自己创作。而今天打开邮箱，又发现George Washington大学的某教授发来邮件询问动画事宜。

只可惜本小子已经半年没更新动画包了。

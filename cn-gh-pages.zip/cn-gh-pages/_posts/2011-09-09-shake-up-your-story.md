---
layout: post
title: 视频两则：世界观与绝望男人
categories:
- Featured
- Life
tags:
- TED
- 视频
---

TED最新出来的一个5分钟演讲“[Shake up your story](http://www.ted.com/talks/raghava_kk_shake_up_your_story.html)”我觉得挺不错，用iPad颠覆娃娃的世界观。其实也不能叫颠覆，因为娃娃本来就没什么世界观。这位父亲的故事书没有定局，晃一晃，印度独立就变成了巴基斯坦视角，再晃一晃，变成了英国视角，娃儿可以看到各种视角下的“爱国”。这又让我想起大和尚，在某朝的长期宣传下，大和尚是个十恶不赦的大坏蛋，他走到哪儿，朝廷就要向哪儿抗议。可是好些天前我第一次读到大和尚的演讲稿时，我真被佛法震撼了，于是我满心疑惑，到底是我too young too naive，还是有什么事不对劲呢。叛徒与爱国者，标准是什么？

<object width="526" height="374">
<param name="movie" value="http://video.ted.com/assets/player/swf/EmbedPlayer.swf"></param>
<param name="allowFullScreen" value="true" />
<param name="allowScriptAccess" value="always"/>
<param name="wmode" value="transparent"></param>
<param name="bgColor" value="#ffffff"></param>
<param name="flashvars" value="vu=http://video.ted.com/talk/stream/2011G/Blank/RaghavaKK_2011G-320k.mp4&su=http://images.ted.com/images/ted/tedindex/embed-posters/RaghavaKK_2011G-embed.jpg&vw=512&vh=288&ap=0&ti=1219&lang=&introDuration=15330&adDuration=4000&postAdDuration=830&adKeys=talk=raghava_kk_shake_up_your_story;year=2011;theme=master_storytellers;theme=art_unusual;event=TEDGlobal+2011;tag=arts;tag=book;tag=creativity;tag=design;tag=entertainment;tag=technology;&preAdTag=tconf.ted/embed;tile=1;sz=512x288;" />
<embed src="http://video.ted.com/assets/player/swf/EmbedPlayer.swf" pluginspace="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent" bgColor="#ffffff" width="526" height="374" allowFullScreen="true" allowScriptAccess="always" flashvars="vu=http://video.ted.com/talk/stream/2011G/Blank/RaghavaKK_2011G-320k.mp4&su=http://images.ted.com/images/ted/tedindex/embed-posters/RaghavaKK_2011G-embed.jpg&vw=512&vh=288&ap=0&ti=1219&lang=&introDuration=15330&adDuration=4000&postAdDuration=830&adKeys=talk=raghava_kk_shake_up_your_story;year=2011;theme=master_storytellers;theme=art_unusual;event=TEDGlobal+2011;tag=arts;tag=book;tag=creativity;tag=design;tag=entertainment;tag=technology;&preAdTag=tconf.ted/embed;tile=1;sz=512x288;"></embed>
</object>

另一则视频名为“[绝望的男银](http://www.ted.com/talks/zimchallenge.html)”，说当今的男性如何糟糕如何不如女性，其中在谈某类动作片时，总结了很重要一点社会现象：如今的（男）人总是被诱惑着做事（称之为*arousal* addictions）。这才是绝望的根源，随着时间推移，需要的诱惑力必须得越来越高，到最后活人只能变成行尸走肉，因为生活越来越难找到乐趣。这是杞人忧天吗？

<object width="526" height="374">
<param name="movie" value="http://video.ted.com/assets/player/swf/EmbedPlayer.swf"></param>
<param name="allowFullScreen" value="true" />
<param name="allowScriptAccess" value="always"/>
<param name="wmode" value="transparent"></param>
<param name="bgColor" value="#ffffff"></param>
<param name="flashvars" value="vu=http://video.ted.com/talk/stream/2011/Blank/PhilipZimbardo_2011-320k.mp4&su=http://images.ted.com/images/ted/tedindex/embed-posters/PhilipZimbardo_2011-embed.jpg&vw=512&vh=288&ap=0&ti=1206&lang=&introDuration=15330&adDuration=4000&postAdDuration=830&adKeys=talk=zimchallenge;year=2011;theme=unconventional_explanations;theme=bold_predictions_stern_warnings;event=TED2011;tag=culture;tag=education;tag=gaming;tag=gender;tag=sex;&preAdTag=tconf.ted/embed;tile=1;sz=512x288;" />
<embed src="http://video.ted.com/assets/player/swf/EmbedPlayer.swf" pluginspace="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent" bgColor="#ffffff" width="526" height="374" allowFullScreen="true" allowScriptAccess="always" flashvars="vu=http://video.ted.com/talk/stream/2011/Blank/PhilipZimbardo_2011-320k.mp4&su=http://images.ted.com/images/ted/tedindex/embed-posters/PhilipZimbardo_2011-embed.jpg&vw=512&vh=288&ap=0&ti=1206&lang=&introDuration=15330&adDuration=4000&postAdDuration=830&adKeys=talk=zimchallenge;year=2011;theme=unconventional_explanations;theme=bold_predictions_stern_warnings;event=TED2011;tag=culture;tag=education;tag=gaming;tag=gender;tag=sex;&preAdTag=tconf.ted/embed;tile=1;sz=512x288;"></embed>
</object>


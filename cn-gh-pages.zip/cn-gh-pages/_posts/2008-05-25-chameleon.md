---
layout: post
title: chameleon 变色蜥蜴
categories: [Life]
tags: [爱生活 爱变态, iBT]
---

正在背单词。这个单词读音与某人名挺像，特此记之。

> chameleon 变色蜥蜴, 变色龙

---
layout: post
title: 开会了开会了
categories:
- Life
tags:
- Joke
---

城管对一个推着小车卖栗子的人喊：

> “明天开会了，你可别出来了，谢谢啊！”

呃……今天发这种Joke貌似不太河蟹……


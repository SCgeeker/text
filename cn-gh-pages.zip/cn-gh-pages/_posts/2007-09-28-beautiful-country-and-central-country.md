---
layout: post
title: 美国：美丽的国家；中国：中部的国家
categories:
- Life
tags:
- 翻译
- 老外
---

刚才在看这个网站的访问记录，CN和US访问量比率大约为27:1，随后是BR、DE、CH、CA……看着这些国家缩写，突然想起上次参加IARIW会议时，一位法国PhD好奇地问我，“听说你们把美国叫做'Beautiful Country'？而中国叫做'Central Country'？”我当时有点瀑布汗，不知道这是哪位中国大哥/大姐如此翻译给她的。我只好结结巴巴告诉她，"beautiful"可能来自"America"的"me"的发音（自己汗，是这样么，“美利坚”到底是谁翻译的）。

下次要是有老外问Law Country、Moral Country、Hero Country怎么办……

好了，作了半天心理准备，终于要开始痛苦地修改以前的程序了。


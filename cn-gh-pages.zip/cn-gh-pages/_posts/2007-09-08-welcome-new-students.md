---
layout: post
title: 开学了，谁最欢迎新生？
categories:
- Life
tags:
- Joke
- 开学
- 财务处
---

据说某校有这样一个横幅：

![开学了，谁最欢迎新生](http://i.imgur.com/y4owt.jpg)


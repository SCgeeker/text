---
layout: post
title: 终于有了个好用的Linux中文输入法
categories:
- Technology
tags:
- iBus
- Linux
- Ubuntu
- 中文输入法
---

> 2012/07/29更新：我最终还是收敛到ibus sunpinyin上了。输入法归根结底，还是习惯问题。

虽然稍微慢了点，不过正确率还蛮高的：ibus-cloud-pinyin。据说是用的搜狗和QQ的云端，不知道寿命会不会长久……之前找了个SCIM Google拼音输入法，但实在是太容易崩溃，另外还有个Sun pinyin，出字速度比我打字速度还慢。

现在彻底转入Ubuntu写书。

---
layout: post
title: 再拜一拜路人们，请教出处：no matter where you go, there you are
categories:
- Life
tags:
- 不耻上问
- 孔子
---

我第一次见到这句话是在UCLA的统计系主任的Skype签名中：

> "And remember, no matter where you go, there you are."

今天在"Quotes of the Day"中又看到了这句话，然后Google了一下，发现出处简直数不胜数，其中有人说是孔夫子讲的，于是我想请教一下各位高人，这句话到底是啥意思、出自哪篇哪章？谢谢！

---
layout: post
title: 第一次见到活的统计大牛们
categories:
- Technology
tags:
- boosting
- Chih-Jen Lin
- Data Mining
- Leo Breiman
- Machine Learning
- Robert Schapire
- SVM
- Tom Mitchell
- Vladimir Vapnik
- 统计牛人
- 视频课程
---

我没去美国，不过见到了Data Mining和Machine Learning界的大圣Leo Breiman作讲座，还见到了Princeton的Robert Schapire讲Boosting（它基本上就是由Schapire最先提出的），我没去台湾，但也见到了支持向量机界的牛人Chih-Jen Lin（SVM界著名的软件库libsvm就是这几个人写的）的一个暑期班讲座。还有很多视频课程（例如还有很多名人诸如Tom Mitchell、Vladimir Vapnik），尽在这个网站：

<http://videolectures.net>

Breiman只留下了一场视频讲座，很遗憾；Schapire的Boosting课非常系统，不妨仔细把两个小时的课听完；Lin的英语口语不太好，毕竟不是native speaker，不过对于中国人来说，这样的英语可能更容易听懂，哈哈。

从这个网站的首页上就足以看出数据挖掘、机器学习以及统计学在当今世道上的盛行。


---
layout: post
title: 归隐
categories:
- Life
tags:
- PhD
- 博士资格考试
- 脑残博士
---

此前忘了声明，到7月8日之前，我偶尔会看看邮箱，但一般不会回复邮件（除非十分重要，比如请我吃饭的、还我钱之类的）。

或有好事者问曰：干嘛去啦？

答曰：正在努力迈向PhD阶段。

又问：嘛是PhD阶段？

答曰：介个还要解释吗？Permanent Head Damage！复习去了，不废话了。

又及：我得重新声明一下，我一般不优先回答直接发我邮箱的R问题（[解释参见FAQ](http://yihui.name/cn/guestbook/)），尤其是在这段时间我几乎不会回答，所有问题请发论坛（<http://cos.name/cn/>）。

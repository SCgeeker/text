---
layout: post
title: 工作学习两不误
categories:
- Life
tags:
- Joke
- 中国群众大学
---

有欢乐的客官发来欢乐的图片一幅，本小子看了也表示很欢乐，供来往行人参观：

![工作学习两不误](http://i.imgur.com/vH2qLRh.jpg)

正溜达着，又看见另一幅很欢快的毕业照：

![欢快毕业照](http://funnyinchina.com/wp-content/uploads/2010/05/teachers-team-photo.jpg)

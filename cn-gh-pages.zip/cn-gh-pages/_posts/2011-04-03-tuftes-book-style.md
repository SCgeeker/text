---
layout: post
title: Tufte样式，纠结了
categories:
- Technology
tags:
- Edward Tufte
- LaTeX
---

知道的越多，迷惑就越多。今天研究了一天Tufte的样式（真的是很漂亮），搞定了所有中文和Sweave问题，不过接下来就要面临选择，要么做苦力，再把一百多幅图一个个调整一遍（主要是压缩宽度和裁左右白边），要么原地踏步走，把几个没有浮好的瓢按到合适的位置上去完事。

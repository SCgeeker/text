---
layout: post
title: 椰林树影，水清沙幼
categories:
- Life
tags:
- JSM
- 会议
---

如题。小的正在迈阿密小岛上参加JSM会议，若有同来的，欢迎吼一嗓子。


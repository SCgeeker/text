---
layout: post
title: 网络上的图片地址
categories:
- Technology
tags:
- 图片
- 论坛
---

我注意到，论坛上间或有人在帖子中发图片用这样的地址：


> file:///c:/documents%20and%20settings/administrator/桌面/qq.bmp


然后冰天雪地跪求，“上图怎样用R画出来啊”或者“我看了一篇论文，用了这幅图，请问是啥意思呀？”，云云。

额滴神呀，汝等也忒幽默了。

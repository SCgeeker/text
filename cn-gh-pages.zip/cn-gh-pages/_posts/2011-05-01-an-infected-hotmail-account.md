---
layout: post
title: 李崇亮，hotmail喊你回家杀毒
categories:
- Technology
tags:
- Hotmail
- 密码
- 杀毒
- 李崇亮
- 邮箱
---

不知道这一嗓子能不能吼到李同学那里去。很长一段时间以来，这同学的hotmail邮箱（aimpursuer@hotmail.com）不断发垃圾邮件过来，而邮箱主人似乎并未察觉，我估摸着八成是MSN病毒。（注：此李乃参加[第一届R语言会议](http://cos.name/2008/12/1st-chinese-r-conference-summary/)的李，别喊错了）

说起这事，就想起某些社交网站的病毒式邀请：让你填邮箱和密码，然后你的所有联系人都会被搜刮出来并强行接收来自于“你”的注册邀请。我脑袋想破了都想不通，为啥会有人真的去填密码。难道这是传说中的IQ卡密码被盗的表现？

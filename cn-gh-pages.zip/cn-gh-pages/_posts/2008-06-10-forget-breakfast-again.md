---
layout: post
title: 又忘了吃饭
categories:
- Life
tags:
- DataViz VI
- 民以食为上帝
- 生活
---

晕，早上爬起来就往办公室走，走到电梯口才想起来忘了吃早饭，又懒得往回走了，于是乎干脆不吃了。有时候中午吃饭太晚的话晚上就容易忘记吃饭，到了半夜肚子饿才想起来，哦，忘了吃晚饭了。

这几天在更新animation程序包，很是累人，不过更新完之后这个包将焕然一新，以后写新的动画函数也方便了。

又：[DataViz VI会议](http://www.jacobs-university.de/schools/shss/awilhelm/13937/)把我安排在第一天演讲，我一看排在前面的人几乎都是大牛，比如Michael Friendly、Lee Wilkinson等牛牛们，我后面还有Di Cook，就我一头无名小毛驴插在中间，噫……微斯人，吾谁与归……

![大牛](http://i.imgur.com/rREkS.png)

![大牛](http://i.imgur.com/rREkS.png)

![大牛](http://i.imgur.com/rREkS.png)

![小毛驴](http://i.imgur.com/ziJPE.png)

![大牛](http://i.imgur.com/rREkS.png)

---
layout: post
title: 数据可视化工具Flare（生成交互式Flash）
categories:
- Technology
tags:
- Flare
- Flash
- 交互
- 动画
---

以前提过的[Processing](http://www.processing.org/)是基于Java语言做动画，这次又发现另一个可视化工具[Flare](http://flare.prefuse.org/)，它可以生成交互式Flash，而且有很多现成模块了。看了一下它的demo，觉得我昨天说的不完整，Flash本身对动画有很多内在的支持，写起代码来应该比Java更快。

有闲工夫的朋友们可以考虑怎样利用Flare改进[Hans Rosling](http://www.ted.com/index.php/talks/hans_rosling_shows_the_best_stats_you_ve_ever_seen.html)的数据表达方式（他只是用了气泡图和密度图，还有很多图形都可以在Flash中继续实现）。

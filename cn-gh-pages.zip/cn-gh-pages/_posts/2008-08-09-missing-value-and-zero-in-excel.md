---
layout: post
title: Excel中的缺失值和0
categories:
- Featured
- Technology
tags:
- '0'
- Excel
- 缺失值
---

假设单元格A1为空，那么若在B1中写公式 "=A1" 的话，则B1=0，显然这是不对的。在捣腾数据的时候慎用Excel。

![](http://i.imgur.com/8aANA.gif)

![](http://i.imgur.com/uNECG.gif)

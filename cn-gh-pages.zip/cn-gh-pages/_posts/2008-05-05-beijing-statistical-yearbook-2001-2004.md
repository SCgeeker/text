---
layout: post
title: 北京市统计年鉴下载（2001~2004年）
categories: [Statistics]
tags: [下载, 北京市统计年鉴]
---

原帖在[这里](http://www.pinggu.org/bbs/dispbbs.asp?BoardID=55&ID=21041)；下载链接请点击[此处](http://15.down.pinggu.org/UploadFile_20082009/2005-5/200557145315567.rar)。

顺路行个方便，免得大家浪费时间。

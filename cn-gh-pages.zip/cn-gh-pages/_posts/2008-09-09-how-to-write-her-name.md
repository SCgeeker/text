---
layout: post
title: 我叫谢益辉，谢是谢益辉的谢
categories:
- Life
tags:
- Joke
- 同学
---

新鲜Joke一则：

刚才办公室某路人乙问，周密的密怎么写？某路人甲回答：秘密的密。

可惜了，这则Joke只能讲，不能写。

然而，路人乙居然写对了。一时间我晕倒两次。

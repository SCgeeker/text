---
layout: post
title: 巷子里赶猪
categories:
- Life
tags:
- 生活
---

我是一头猪，在一条巷子里被赶来赶去。在这儿拱一拱泥，在那儿啃一啃萝卜皮。反正就是没有安身之地。


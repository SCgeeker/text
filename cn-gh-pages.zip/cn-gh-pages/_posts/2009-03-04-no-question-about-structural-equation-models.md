---
layout: post
title: 终于有人自觉地不问我结构方程模型问题了
categories:
- Life
tags:
- SEM
- 结构方程模型
---

刚刚有人前脚发邮件问SEM的问题，后脚又跟着补发邮件说看到我关于SEM的声明，不用回答了。我顿时一个老泪纵横啊！！

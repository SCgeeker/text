---
layout: post
title: 再来一个眼球实验：找出黑黑猪
categories:
- Life
tags:
- Flash游戏
- 眼球
---

这次跟[统计和假设检验](http://yihui.name/cn/2008/09/eyeball-test-fake-coin/)没有关系。点中间那只女猪开始吧（友情提醒眼珠子转晕了的童鞋们莫找我麻烦啊）：




若现这个Flash太小了，那么可以[点此全屏Flash](http://photo.heyheypig.com/HeyHeyPhoto/Game/b20072817441753.swf)以便看得更清楚。

---
layout: post
title: 世上最痛苦的事
categories:
- Technology
tags:
- LaTeX
- Word
---

莫过于把LaTeX生成的PDF文档转成Word。

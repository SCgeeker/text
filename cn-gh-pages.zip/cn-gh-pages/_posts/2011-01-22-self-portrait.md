---
layout: post
title: 自画像
categories:
- Featured
- Life
tags:
- 自画像
---

上不了厅堂，下得了厨房；  
敲得了代码，逮得住蟑螂。

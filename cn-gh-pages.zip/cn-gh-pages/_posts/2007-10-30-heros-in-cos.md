---
layout: post
title: “统计之都”英雄榜（持续更新中）
categories:
- Life
tags:
- 人力资源
- 统计之都
---

“统计之都”自从2006年5月19日建站起（`difftime('2007-10-27', '2006-5-19')`），已经积累了约三万五千会员，其中卧虎藏龙有不少英雄人物，其实很久以来都想整理一下这一大批资源，只是迟迟未动手。凭我一双浊眼，必然也有漏掉的，从今天开始慢慢列举吧（ID排序、排名不分先后）：

- [abel](http://cos.name/cn/profile/123)：数理统计是强项，R爱好者
- [amzon007](http://cos.name/cn/profile/63)：医学统计（跑到美国去了，很久没在论坛上吱声了）
- [anita_jiu](http://cos.name/cn/profile/1006)：SPSS，商务、市场方面的统计学`*`
- [anning189](http://cos.name/cn/profile/3849)：R
- [areg](http://cos.name/cn/profile/3878)：生物统计，R/S-Plus，异常勤奋的研究者（现在不知道在哪个草原上做试验，半年多没回论坛了）
- [bjt](http://cos.name/cn/profile/336)：精通R（编写了[R frequently asked questions](http://cos.name/cn/topic/7673)），也是LaTeX爱好者
- [colinisstudent](http://cos.name/cn/profile/12)：认真负责的版主，COS的大功臣，对考研的同学帮助巨大
- [cran](http://cos.name/cn/profile/209)：看ID就知道和R有某种关系，生物统计，MCMC，Bayesian，SAS，Mixed Model`*`
- [ECONOMETRICS](http://cos.name/cn/profile/3813)：Copula
- [fire_cpp](http://cos.name/cn/profile/5777)：Linux，R
- [hangover](http://cos.name/cn/profile/241)：C语言，统计计算，MCMC`*`
- [huadli](http://cos.name/cn/profile/1083)：SAS
- [ilikemath](http://cos.name/cn/profile/1754)：数理统计
- [jyma](http://cos.name/cn/profile/1781)：数理统计、机器学习
- [longoR++](http://cos.name/cn/profile/10801)：参见[rtist](http://cos.name/cn/profile/230)`*`
- [losttemple](http://cos.name/cn/profile/9580)：SAS
- [momozilla](http://cos.name/cn/profile/28289)：R，Emacs+ESS
- [Msmart ](http://cos.name/cn/profile/496)：数理统计`*`
- [neige](http://cos.name/cn/profile/16503)：R`*`
- [nurseshark](http://cos.name/cn/profile/65)：认真负责的版主
- [pengchy](http://cos.name/cn/profile/6119)：R，计算
- [redlou](http://cos.name/cn/profile/7391)：数理统计，生物统计
- [robustreg](http://cos.name/cn/profile/18223)：名如其人，稳健统计（robust statistics）
- [rtist](http://cos.name/cn/profile/230)：数理统计功底比较扎实，熟悉统计计算，精通R，老本行在生物统计方面（这位“艺术家”是COS论坛的一大核心支柱，认真负责的版主）`*`
- [sheldonpeng](http://cos.name/cn/profile/917)：发帖虽不多，但可以看出精通Java语言以及Java和R的接口（rJava包等）
- [shoeda](http://cos.name/cn/profile/44)：SPSS
- [shunqinature](http://cos.name/cn/profile/32587)：数理统计`*`
- [sociology](http://cos.name/cn/profile/4418)：社会学，统计学，R
- [Statsfu](http://cos.name/cn/profile/26735)：数理统计，SAS`*`
- [wintarcy](http://cos.name/cn/profile/6513)：R，新来者，但具有钻研精神
- [wumaths](http://cos.name/cn/profile/5828)：数理统计`*`
- [xifan](http://cos.name/cn/profile/46)：经济统计，认真负责的版主
- [ypchen](http://cos.name/cn/profile/20)：强项数理统计，开源软件爱好者
- [南田](http://cos.name/cn/profile/11844)：数据挖掘`*`
- [謝邦昌](http://cos.name/cn/profile/61)：数据挖掘，一位牛牛的和蔼的台湾Prof

对了，要不给[lucky](http://cos.name/cn/profile/68)封一个“大力水手”的称号如何……


---
layout: post
title: 新论坛太复杂了
categories:
- Technology
tags:
- COS论坛
- 统计之都
---

新版[COS论坛](http://cos.name/bbs)简直太它NND复杂了，把老夫折腾得晕头转向！……

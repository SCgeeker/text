---
layout: post
title: 如果你不懂HTML，你连笑话都看不懂
categories:
- Technology
tags:
- HTML
- 标签
- 现代人
---

刚写完那个引用自己硬盘图片地址的，突然想起两张陈年老图：

![停止战争](http://i.imgur.com/kMHEf.jpg)

![比萨斜塔](http://i.imgur.com/tudJt.jpg)

它们深刻说明了：作为现代人，不懂HTML是不行滴。


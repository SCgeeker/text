---
title: links
layout: page
comments: yes
---

# 个人

姓名拼音排序：

- [陈钢](http://www.gossipcoder.com/) 中南大学，useR，生物信息学，译者
- [陈丽云](http://www.loyhome.cn/) 山东大学，经济学，网站控，useR
- [范建宁](http://blog.cos.name/fan) 川大人大，量化投资，useR，许三多
- [高涛](http://joegaotao.github.io) 唇红齿白
- [胡江堂](http://li-and-jiang.com/blog/) 北大软件学院，经济学，SAS程序员，一肚子墨水，一手好字
- [刘思喆](http://www.bjt.name/) 人大，useR，数据挖掘
- [邱怡轩](http://yixuan.cos.name/) 人大，useR，GNU，统计，过细之人
- [魏太云](http://blog.cos.name/taiyun) 中南大学/人大，useR，可视化，数学建模，文绉绉
- [肖楠](http://www.road2stat.com/) 中南大学，useR，技术控
- [颜林林](http://yanlinlin82.vicp.net/blog/) useR，GNU，生物
- [殷腾飞](http://www.tengfei.name/) ISU，生物，统计

# 统计

- [统计之都](http://cos.name) 国内的统计学网站先驱
- [雪晴数据网](http://www.xueqing.cc) 数据科学在线学习社区

# 软件

- [R语言](http://www.r-project.org) 自由的统计计算和图形软件
- [pandoc](http://johnmacfarlane.net/pandoc/) 强大的文档转换工具，极客必备杀器，以防愣头客户索要Word版本
- [LyX](http://www.lyx.org) 让LaTeX死忠死忠去吧，反正我讨厌阅读TeX源代码

